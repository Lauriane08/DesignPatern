public class BruteForceLocalPasswordCracker implements LocalPasswordCracker {
    @Override
    public String crack(String hash) {
        return "MotDePasse123"; // Exemple simplifié de la méthode de force brute
    }
}
