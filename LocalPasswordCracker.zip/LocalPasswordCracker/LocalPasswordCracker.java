interface LocalPasswordCracker {
    String crack(String hash);
}
