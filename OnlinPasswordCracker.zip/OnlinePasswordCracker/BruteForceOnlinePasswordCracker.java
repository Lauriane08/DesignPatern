import java.util.HashMap;
import java.util.Map;

class BruteForceOnlinePasswordCracker implements OnlinePasswordCracker {
    @Override
    public String crack(String url, String login,String passwd) {
        // Implémentation de la méthode de force brute en ligne
        String[] commonPasswords = {"password", "123456", "qwerty", "abc123","admin@123"}; // Liste de mots de passe
        Map<String, String> userCredentials = new HashMap<>();
        String key = url + "/" + login;
        for (String password : commonPasswords) {
            userCredentials.put(key, password);
            if(userCredentials.get(key) == passwd){
                return passwd;
            }

        }
        return null;

      
        
    }
/* 
    private boolean isValidPassword(String url, String login, String password) {
        String[] commonPasswords = {"password", "123456", "qwerty", "abc123"};
        Map<String, String> userCredentials = new HashMap<>();
        String key = url + "/" + login;
        for(String p : commonPasswords){
            userCredentials.put(key, p);
        }

        if(userCredentials.containsKey(password)){
            return true;
        }
        return false;
          
    } */
}

