interface OnlinePasswordCracker {
    String crack(String url, String login, String passwd);
}
